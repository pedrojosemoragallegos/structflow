import typing

AttributeValue: typing.TypeAlias = typing.Union[str, int, float, bool, None]
